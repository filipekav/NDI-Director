"""
sse_manager.py — Infraestrutura de Server-Sent Events (SSE).

Mantém a lista de clientes conectados e permite notificá-los
instantaneamente quando qualquer estado do sistema mudar.
"""
import queue
import threading

_sse_listeners: list = []
_sse_lock = threading.Lock()


def notificar_clientes() -> None:
    """Envia um evento de atualização para todos os clientes SSE conectados."""
    with _sse_lock:
        for q in _sse_listeners[:]:
            try:
                q.put_nowait("update")
            except queue.Full:
                pass


def criar_fila_cliente() -> queue.Queue:
    """Registra um novo cliente SSE e retorna sua fila de eventos."""
    q = queue.Queue(maxsize=10)
    with _sse_lock:
        _sse_listeners.append(q)
    return q


def remover_fila_cliente(q: queue.Queue) -> None:
    """Remove a fila de um cliente SSE desconectado."""
    with _sse_lock:
        try:
            _sse_listeners.remove(q)
        except ValueError:
            pass
