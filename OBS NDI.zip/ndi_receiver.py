"""
ndi_receiver.py — Classe ReceptorNDI.

Cada instância roda em uma thread dedicada, conecta a uma fonte NDI
específica na rede e mantém o frame mais recente disponível.
Suporta reconexão automática quando o feed cai.
"""
import threading
import time

import numpy as np
import NDIlib as ndi

import config
import sse_manager


class ReceptorNDI:
    """Receptor de frames NDI com reconexão automática e flag de erro."""

    def __init__(self, target_name: str):
        self.target_name = target_name
        self.frame_atual = None
        self.rodando = True
        self.erro = False  # True quando o feed está perdido / reconectando
        self.thread = threading.Thread(target=self._loop_recepcao, daemon=True)
        self.thread.start()

    def _loop_recepcao(self) -> None:
        """Loop externo: tenta conectar; se perder o feed, aguarda e reconecta."""
        while self.rodando:
            self.erro = False
            try:
                self._conectar_e_receber()
            except Exception as e:
                print(f"[!] Erro no receptor '{self.target_name}': {e}")

            if self.rodando:
                # Feed perdido — sinaliza erro e aguarda 3s antes de reconectar
                self.erro = True
                sse_manager.notificar_clientes()
                print(f"[~] Reconectando '{self.target_name}' em 3s...")
                for _ in range(30):   # 30 × 0.1s = 3s
                    if not self.rodando:
                        break
                    time.sleep(0.1)

    def _conectar_e_receber(self) -> None:
        """Localiza a fonte NDI, conecta e recebe frames até perdê-los ou parar."""
        ndi_find = ndi.find_create_v2()
        if ndi_find is None:
            raise RuntimeError("Falha ao criar instância de busca NDI.")

        target_source = None
        for _ in range(10):   # Busca por até 10 segundos
            if not self.rodando:
                break
            ndi.find_wait_for_sources(ndi_find, 1000)
            fontes = ndi.find_get_current_sources(ndi_find)
            for f in fontes:
                if self.target_name == f.ndi_name:
                    target_source = f
                    break
            if target_source:
                break

        if not target_source or not self.rodando:
            ndi.find_destroy(ndi_find)
            if not target_source:
                raise RuntimeError(f"Fonte '{self.target_name}' não encontrada na rede.")
            return

        recv_desc = ndi.RecvCreateV3()
        recv_desc.color_format = ndi.RECV_COLOR_FORMAT_BGRX_BGRA
        ndi_recv = ndi.recv_create_v3(recv_desc)
        ndi.recv_connect(ndi_recv, target_source)
        ndi.find_destroy(ndi_find)

        frames_sem_receber = 0
        while self.rodando:
            t, v, _, _ = ndi.recv_capture_v2(ndi_recv, 200)
            if t == ndi.FRAME_TYPE_VIDEO:
                self.frame_atual = np.copy(v.data)
                ndi.recv_free_video_v2(ndi_recv, v)
                frames_sem_receber = 0
                self.erro = False
            else:
                frames_sem_receber += 1
                # Mais de ~5s sem frames: considera o feed perdido
                if frames_sem_receber > 25:
                    ndi.recv_destroy(ndi_recv)
                    raise RuntimeError(f"Feed '{self.target_name}' parou de transmitir.")

        ndi.recv_destroy(ndi_recv)

    def parar(self) -> None:
        """Sinaliza para a thread de recepção parar."""
        self.rodando = False
