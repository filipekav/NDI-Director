"""
ndi_scanner.py — Thread de descoberta de fontes NDI na rede local.

Varre a rede a cada 2 segundos e atualiza a lista global `fontes_na_rede`
em config.py, filtrando fontes internas e feeds dinâmicos do Teams/Zoom.
"""
import NDIlib as ndi
import config


def scanner_ndi_rede() -> None:
    """Loop infinito (daemon thread) que descobre fontes NDI disponíveis."""
    ndi_find = ndi.find_create_v2()
    if ndi_find is None:
        print("[!] Scanner NDI: falha ao inicializar instância de busca.")
        return

    while True:
        ndi.find_wait_for_sources(ndi_find, 2000)   # Varre a cada 2 segundos
        fontes_atuais = ndi.find_get_current_sources(ndi_find)
        nomes = [f.ndi_name for f in fontes_atuais]

        # Filtra fontes internas e feeds dinâmicos que não pertencem ao painel
        nomes_filtrados = []
        for n in nomes:
            if "MESA_NDI_MOSAICO" in n:       # nossa própria saída principal
                continue
            if "MESA_NDI_VERTICAL" in n:      # nossa própria saída vertical
                continue
            if "Orador ativo" in n or "Active Speaker" in n:  # Teams/Zoom
                continue
            nomes_filtrados.append(n)

        with config.lock_fontes:
            config.fontes_na_rede = nomes_filtrados
