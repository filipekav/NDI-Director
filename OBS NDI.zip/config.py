"""
config.py — Estado global compartilhado entre todos os módulos do OBS NDI Mesa de Corte.

Todos os módulos importam daqui para evitar importações circulares.
"""
import threading

# --- CONFIGURAÇÃO ---
EXIBIR_JANELA_LOCAL = False  # True = abre janela OpenCV na área de trabalho

# --- ESTADO NDI ---
fontes_na_rede: list = []          # Nomes das fontes NDI descobertas na rede
receptores_ativos: dict = {}       # { "Nome da Fonte": ReceptorNDI }
ordem_receptores: list = [None, None, None, None]  # Slots fixos de posição (1–4)
fonte_highlight: str | None = None # Fonte em modo destaque (70/30)
fonte_solo:      str | None = None # Fonte em modo solo (tela cheia exclusiva)
apelidos_fontes: dict = {}         # { "Nome NDI": "Apelido GC" }

# --- FUNDO DO MOSAICO (Chroma Key para OBS) ---
CORES_BACKGROUND = {
    "cinza":        (15, 15, 15, 255),
    "verde":        (0, 255, 0, 255),
    "azul":         (255, 0, 0, 255),
    "preto":        (0, 0, 0, 255),
    "transparente": (0, 0, 0, 0),   # Alpha = 0 (transparência nativa NDI)
}
cor_fundo_atual: str = "verde"

# --- JANELA LOCAL (OpenCV) ---
hwnd_janela = None
arrastando_janela: bool = False
mouse_start_x: int = 0
mouse_start_y: int = 0

# --- LOCK GLOBAL ---
lock_fontes = threading.Lock()
