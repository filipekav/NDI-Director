"""
main.py — Entry point da Mesa de Corte NDI.

Inicia as três componentes do sistema em paralelo:
  1. Thread: scanner NDI (descobre fontes na rede)
  2. Thread: servidor web Flask (painel de controle em http://localhost:8634)
  3. Main thread: motor de vídeo OpenCV + NDI Output (deve rodar na main thread)
"""
import threading

from ndi_scanner import scanner_ndi_rede
from video_engine import iniciar_motor_de_video
from web.routes import iniciar_servidor_web   # registra as rotas no app Flask


if __name__ == '__main__':
    # 1. Scanner NDI em background
    threading.Thread(target=scanner_ndi_rede, daemon=True).start()

    # 2. Servidor web em background
    threading.Thread(target=iniciar_servidor_web, daemon=True).start()

    # 3. Motor de vídeo na main thread (exigência do OpenCV no Windows)
    iniciar_motor_de_video()