"""
video_engine.py — Motor de vídeo: composição OpenCV + saída NDI.

Responsável por:
- Renderizar o mosaico dinâmico (1–4 feeds) em um canvas BGRA 1920×850 (MESA_NDI_MOSAICO)
- Renderizar grade vertical simultânea 550×850 (MESA_NDI_VERTICAL) sem modo highlight
- Aplicar o GC (Gerador de Caracteres) sobre cada feed
- Transmitir o resultado via NDI Output como 'MESA_NDI_MOSAICO'
- Opcional: exibir janela local OpenCV borderless
"""
import os
import time
import ctypes
from ctypes import wintypes

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import NDIlib as ndi

import config


# ---------------------------------------------------------------------------
# Fonte Anton (TrueType) — carregada uma vez e cacheada por tamanho
# ---------------------------------------------------------------------------

_FONT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ANTON-REGULAR.TTF')
_anton_cache: dict = {}

def _get_anton(tamanho: int) -> ImageFont.FreeTypeFont:
    """Retorna instância cacheada da fonte Anton para o tamanho solicitado."""
    if tamanho not in _anton_cache:
        try:
            _anton_cache[tamanho] = ImageFont.truetype(_FONT_PATH, tamanho)
        except Exception as e:
            print(f'[!] Fonte Anton nao encontrada ({e}). Usando fallback.')
            _anton_cache[tamanho] = ImageFont.load_default()
    return _anton_cache[tamanho]


# ---------------------------------------------------------------------------
# Renderizacao individual de cada feed no canvas
# ---------------------------------------------------------------------------

def desenhar_com_aspect_ratio(
    canvas, frame, x: int, y: int, max_w: int, max_h: int,
    texto_exibicao: str | None = None
) -> None:
    """Desenha o frame no canvas respeitando aspect ratio, sem sombras, e aplica o GC por cima."""
    h, w = frame.shape[:2]
    escala = min(max_w / w, max_h / h)
    novo_w = int(w * escala)
    novo_h = int(h * escala)

    frame_redimensionado = cv2.resize(frame, (novo_w, novo_h), interpolation=cv2.INTER_LINEAR)

    offset_x = x + (max_w - novo_w) // 2
    offset_y = y + (max_h - novo_h) // 2

    # --- Desenha o frame diretamente no canvas ---
    canvas[offset_y:offset_y + novo_h, offset_x:offset_x + novo_w, 0:3] = frame_redimensionado[:, :, :3]
    canvas[offset_y:offset_y + novo_h, offset_x:offset_x + novo_w, 3] = 255

    # --- Desenha o GC (Gerador de Caracteres) ---
    if texto_exibicao:
        if max_w > 1000:
            font_size = 44
        elif max_w < 600:
            font_size = 24
        else:
            font_size = 32

        font = _get_anton(font_size)
        bbox = font.getbbox(texto_exibicao)
        tw_pil = bbox[2] - bbox[0]
        th_pil = bbox[3] - bbox[1]

        padding_x = 18
        padding_v = 10
        altura_barra = th_pil + padding_v * 2

        gc_x1 = offset_x
        gc_y1 = offset_y + novo_h - altura_barra
        gc_x2 = min(offset_x + tw_pil + 2 * padding_x, offset_x + novo_w)
        gc_y2 = offset_y + novo_h

        bar_w = gc_x2 - gc_x1
        bar_h = max(1, gc_y2 - gc_y1)

        roi = canvas[gc_y1:gc_y2, gc_x1:gc_x2]
        fundo = roi.copy()
        fundo[:, :, :4] = (4, 0, 84, 255)
        canvas[gc_y1:gc_y2, gc_x1:gc_x2, :3] = cv2.addWeighted(
            fundo[:, :, :3], 0.85, roi[:, :, :3], 0.15, 0
        )
        canvas[gc_y1:gc_y2, gc_x1:gc_x2, 3] = 255

        pil_bar = Image.new('RGBA', (bar_w, bar_h), (0, 0, 0, 0))
        pil_draw = ImageDraw.Draw(pil_bar)
        tx = padding_x - bbox[0]
        ty = padding_v - bbox[1]
        pil_draw.text((tx, ty), texto_exibicao, font=font, fill=(255, 255, 255, 255))

        arr = np.array(pil_bar)
        mask = arr[:, :, 3:4] / 255.0
        bgr_pil = arr[:, :, [2, 1, 0]]

        roi_c = canvas[gc_y1:gc_y2, gc_x1:gc_x2]
        roi_c[:, :, :3] = (bgr_pil * mask + roi_c[:, :, :3] * (1.0 - mask)).astype(np.uint8)
        roi_c[:, :, 3] = 255
        canvas[gc_y1:gc_y2, gc_x1:gc_x2] = roi_c

_posicoes_atuais: dict = {}   # { nome: [x, y, max_w, max_h]  (floats) }
_LERP_FATOR = 0.50            # 0.08 = muito suave | 0.20 = mais rapido

_W, _H, _PAD = 1920, 850, 10  # dimensoes fixas do canvas principal


def _calcular_posicoes_alvo(frames_ativos: list, nome_highlight: str | None) -> dict:
    """Retorna {nome: (x, y, max_w, max_h)} para o layout alvo deste frame."""
    W, H, pad = _W, _H, _PAD
    n   = len(frames_ativos)
    pos: dict = {}

    # --- Modo Solo ---
    if config.fonte_solo:
        for nome, _, _ in frames_ativos:
            if nome == config.fonte_solo:
                return {nome: (pad, pad, W - 2*pad, H - 2*pad)}
        config.fonte_solo = None   # feed saiu da cena

    # Separa highlight dos secundarios
    hl_nome   = None
    sec_nomes = []
    for nome, _, _ in frames_ativos:
        if nome == nome_highlight:
            hl_nome = nome
        else:
            sec_nomes.append(nome)

    # --- Modo Highlight (layout 70/30) ---
    if hl_nome is not None:
        if n == 1:
            pos[hl_nome] = (pad, pad, W - 2*pad, H - 2*pad)
        else:
            larg_util = W - 3*pad
            W_esq     = int(larg_util * 0.70)
            W_dir     = larg_util - W_esq
            H_util    = H - 2*pad
            pos[hl_nome] = (pad, pad, W_esq, H_util)

            n_sec   = len(sec_nomes)
            h_bloco = (H_util - (n_sec - 1)*pad) // n_sec
            px_dir  = pad + W_esq + pad
            for i, nome in enumerate(sec_nomes):
                py = pad + i * (h_bloco + pad)
                pos[nome] = (px_dir, py, W_dir, h_bloco)
        return pos

    # --- Mosaico Simetrico ---
    nomes = [nome for nome, _, _ in frames_ativos]
    if n == 1:
        pos[nomes[0]] = (pad, pad, W - 2*pad, H - 2*pad)
    elif n == 2:
        wb = (W - 3*pad) // 2
        hb = H - 2*pad
        pos[nomes[0]] = (pad,            pad, wb, hb)
        pos[nomes[1]] = (pad + wb + pad, pad, wb, hb)
    elif n == 3:
        wb = (W - 3*pad) // 2
        hb = (H - 3*pad) // 2
        locs = [(pad, pad), (pad + wb + pad, pad), ((W - wb)//2, pad + hb + pad)]
        for i, (px, py) in enumerate(locs):
            pos[nomes[i]] = (px, py, wb, hb)
    else:  # n >= 4
        wb = (W - 3*pad) // 2
        hb = (H - 3*pad) // 2
        locs = [(pad, pad), (pad + wb + pad, pad),
                (pad, pad + hb + pad), (pad + wb + pad, pad + hb + pad)]
        for i in range(min(n, 4)):
            pos[nomes[i]] = (locs[i][0], locs[i][1], wb, hb)

    return pos


# ---------------------------------------------------------------------------
# Composicao do mosaico dinamico (com transicao suave)
# ---------------------------------------------------------------------------

def renderizar_matriz_dinamica(canvas, frames_ativos: list, nome_highlight_ativo: str | None = None) -> None:
    """Compoe o layout final no canvas com transicoes suaves (lerp) entre layouts."""
    global _posicoes_atuais

    n = len(frames_ativos)
    if n == 0:
        _posicoes_atuais.clear()
        cv2.putText(
            canvas, "Aguardando Fontes...",
            (700, 540), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (100, 100, 100, 255), 3, cv2.LINE_AA
        )
        return

    # Calcula onde cada feed DEVE estar neste frame
    alvo = _calcular_posicoes_alvo(frames_ativos, nome_highlight_ativo)

    # Interpola posicoes atuais -> alvo
    for nome, (ax, ay, aw, ah) in alvo.items():
        if nome not in _posicoes_atuais:
            # Nova fonte: inicia diretamente no alvo (sem animacao de entrada)
            _posicoes_atuais[nome] = [float(ax), float(ay), float(aw), float(ah)]
        else:
            cur = _posicoes_atuais[nome]
            t   = _LERP_FATOR
            cur[0] += (ax - cur[0]) * t
            cur[1] += (ay - cur[1]) * t
            cur[2] += (aw - cur[2]) * t
            cur[3] += (ah - cur[3]) * t

    # Remove feeds que sairam da cena
    for nome in list(_posicoes_atuais.keys()):
        if nome not in alvo:
            del _posicoes_atuais[nome]

    # Mapa nome -> (frame, apelido) para renderizacao
    frame_map = {nome: (frame, apelido) for nome, frame, apelido in frames_ativos}

    # Renderiza cada feed na posicao interpolada
    for nome, pos in _posicoes_atuais.items():
        if nome in frame_map:
            frame, apelido = frame_map[nome]
            x, y, mw, mh = int(pos[0]), int(pos[1]), int(pos[2]), int(pos[3])
            if mw > 0 and mh > 0:
                desenhar_com_aspect_ratio(canvas, frame, x, y, mw, mh, apelido)



# ---------------------------------------------------------------------------
# Composição da grade vertical (NDI secundário 550×850 — sem highlight)
# ---------------------------------------------------------------------------

def renderizar_grade_vertical(canvas, frames_ativos: list) -> None:
    """Empilha os feeds verticalmente no canvas 550×850 sem aplicar modo highlight."""
    W_V, H_V = 550, 850
    n = len(frames_ativos)
    if n == 0:
        cv2.putText(
            canvas, "Aguardando...",
            (60, H_V // 2), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (100, 100, 100, 255), 2, cv2.LINE_AA
        )
        return

    pad = 8
    n_vis = min(n, 4)
    h_bloco = (H_V - (n_vis + 1) * pad) // n_vis

    for i, (_, frame, apelido) in enumerate(frames_ativos[:4]):
        py = pad + i * (h_bloco + pad)
        desenhar_com_aspect_ratio(canvas, frame, pad, py, W_V - 2 * pad, h_bloco, apelido)


# ---------------------------------------------------------------------------
# Callback de mouse (janela local borderless)
# ---------------------------------------------------------------------------

def mouse_callback(event, x: int, y: int, flags, param) -> None:
    """Permite arrastar a janela OpenCV borderless pelo mouse."""
    if not config.hwnd_janela:
        return

    user32 = ctypes.windll.user32

    if event == cv2.EVENT_LBUTTONDOWN:
        config.arrastando_janela = True
        config.mouse_start_x = x
        config.mouse_start_y = y
    elif event == cv2.EVENT_MOUSEMOVE and config.arrastando_janela:
        rect = wintypes.RECT()
        user32.GetWindowRect(config.hwnd_janela, ctypes.byref(rect))
        largura = rect.right - rect.left
        altura = rect.bottom - rect.top
        user32.MoveWindow(
            config.hwnd_janela,
            rect.left + (x - config.mouse_start_x),
            rect.top + (y - config.mouse_start_y),
            largura, altura, True
        )
    elif event == cv2.EVENT_LBUTTONUP:
        config.arrastando_janela = False


# ---------------------------------------------------------------------------
# Loop principal do motor de vídeo
# ---------------------------------------------------------------------------

def iniciar_motor_de_video() -> None:
    """Inicializa NDI Output e roda o loop de composição/transmissão em 30 FPS."""
    if not ndi.initialize():
        print("Erro: NDI não pôde ser inicializado.")
        return

    # --- Transmissor principal: MESA_NDI_MOSAICO (1920×850) ---
    send_settings = ndi.SendCreate()
    send_settings.ndi_name = "MESA_NDI_MOSAICO"
    ndi_send = ndi.send_create(send_settings)

    video_frame = ndi.VideoFrameV2()
    video_frame.xres = 1920
    video_frame.yres = 850
    video_frame.FourCC = ndi.FOURCC_VIDEO_TYPE_BGRA
    video_frame.line_stride_in_bytes = 1920 * 4
    video_frame.frame_rate_N = 30000
    video_frame.frame_rate_D = 1001   # ~29.97 fps
    video_frame.picture_aspect_ratio = 1920.0 / 850.0
    video_frame.frame_format_type = ndi.FRAME_FORMAT_TYPE_PROGRESSIVE

    canvas = np.zeros((850, 1920, 4), dtype=np.uint8)

    # --- Transmissor vertical: MESA_NDI_VERTICAL (550×850) ---
    send_settings_v = ndi.SendCreate()
    send_settings_v.ndi_name = "MESA_NDI_VERTICAL"
    ndi_send_v = ndi.send_create(send_settings_v)

    video_frame_v = ndi.VideoFrameV2()
    video_frame_v.xres = 550
    video_frame_v.yres = 850
    video_frame_v.FourCC = ndi.FOURCC_VIDEO_TYPE_BGRA
    video_frame_v.line_stride_in_bytes = 550 * 4
    video_frame_v.frame_rate_N = 30000
    video_frame_v.frame_rate_D = 1001   # ~29.97 fps
    video_frame_v.picture_aspect_ratio = 550.0 / 850.0
    video_frame_v.frame_format_type = ndi.FRAME_FORMAT_TYPE_PROGRESSIVE

    canvas_v = np.zeros((850, 550, 4), dtype=np.uint8)

    # Janela local opcional
    if config.EXIBIR_JANELA_LOCAL:
        cv2.namedWindow("SAIDA_MATRIZ_OBS", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("SAIDA_MATRIZ_OBS", 1920, 850)
        cv2.setMouseCallback("SAIDA_MATRIZ_OBS", mouse_callback)

        time.sleep(0.15)
        user32 = ctypes.windll.user32
        config.hwnd_janela = user32.FindWindowW(None, "SAIDA_MATRIZ_OBS")
        if config.hwnd_janela:
            GWL_STYLE = -16
            user32.SetWindowLongW(config.hwnd_janela, GWL_STYLE, 0x80000000 | 0x10000000 | 0x00080000)
            user32.SetWindowPos(config.hwnd_janela, 0, 0, 0, 0, 0, 0x0027)
            print("[*] Janela configurada em modo Borderless (Arraste suave ativado)")

        cv2.setWindowProperty("SAIDA_MATRIZ_OBS", cv2.WND_PROP_ASPECT_RATIO, cv2.WINDOW_KEEPRATIO)

    print("========================================")
    print(" MOTOR DE VÍDEO PRONTO E RODANDO ")
    print(" TRANSMISSOR NDI ATIVADO: 'MESA_NDI_MOSAICO' (1920x850)")
    print(" TRANSMISSOR NDI ATIVADO: 'MESA_NDI_VERTICAL' (550x850)")
    print(" 1. Adicione 'NDI Source' no OBS com nome 'MESA_NDI_MOSAICO'")
    print(" 2. Adicione 'NDI Source' no OBS com nome 'MESA_NDI_VERTICAL' (feed vertical)")
    print(" 3. Para transparência nativa, selecione 'Transparente Nativo' no painel!")
    print("========================================")

    # Fundo estático pré-renderizado (evita recriar o array a cada frame)
    fundo_estatico    = np.full((850, 1920, 4), (15, 15, 15, 255), dtype=np.uint8)
    fundo_estatico_v  = np.full((850, 550,  4), (15, 15, 15, 255), dtype=np.uint8)
    cor_fundo_renderizada = "cinza"

    while True:
        tempo_inicio = time.time()

        # Atualiza o fundo apenas quando a cor mudar
        if cor_fundo_renderizada != config.cor_fundo_atual:
            cor_fundo_renderizada = config.cor_fundo_atual
            fundo_estatico[:]   = config.CORES_BACKGROUND[config.cor_fundo_atual]
            fundo_estatico_v[:] = config.CORES_BACKGROUND[config.cor_fundo_atual]
            print(f"[#] Fundo atualizado para: {config.cor_fundo_atual}")

        frames_para_desenhar = []
        with config.lock_fontes:
            for nome in config.ordem_receptores:
                if nome and nome in config.receptores_ativos:
                    rec = config.receptores_ativos[nome]
                    if rec.frame_atual is not None:
                        apelido = config.apelidos_fontes.get(nome, "")  # vazio = sem GC
                        frames_para_desenhar.append((nome, rec.frame_atual, apelido))

        # CPU ociosa: 2 FPS quando não há feeds; 30 FPS quando há
        fps_alvo = 30 if frames_para_desenhar else 2
        tempo_por_frame = 1.0 / fps_alvo

        # --- Canvas principal (1920×850) ---
        np.copyto(canvas, fundo_estatico)   # np.copyto é ~16× mais rápido que canvas[:] = ...
        renderizar_matriz_dinamica(canvas, frames_para_desenhar, config.fonte_highlight)

        frame_saida = np.ascontiguousarray(canvas)
        video_frame.data = frame_saida
        if ndi_send:
            ndi.send_send_video_v2(ndi_send, video_frame)

        # --- Canvas vertical (550×850) — sem highlight ---
        np.copyto(canvas_v, fundo_estatico_v)
        renderizar_grade_vertical(canvas_v, frames_para_desenhar)

        frame_saida_v = np.ascontiguousarray(canvas_v)
        video_frame_v.data = frame_saida_v
        if ndi_send_v:
            ndi.send_send_video_v2(ndi_send_v, video_frame_v)

        if config.EXIBIR_JANELA_LOCAL:
            cv2.imshow("SAIDA_MATRIZ_OBS", canvas)

            # Garante proporção 16:9 se a janela for redimensionada manualmente
            try:
                rect = cv2.getWindowImageRect("SAIDA_MATRIZ_OBS")
                if rect and len(rect) >= 4:
                    _, _, ww, wh = rect
                    if ww > 0 and wh > 0 and abs(ww / wh - 1920 / 850) > 0.01:
                        cv2.resizeWindow("SAIDA_MATRIZ_OBS", ww, int(ww * 850 / 1920))
            except Exception:
                pass

            tempo_decorrido = time.time() - tempo_inicio
            if cv2.waitKey(int(max(1, (tempo_por_frame - tempo_decorrido) * 1000))) & 0xFF == ord('q'):
                break
        else:
            tempo_decorrido = time.time() - tempo_inicio
            time.sleep(max(0.001, tempo_por_frame - tempo_decorrido))

    # Limpeza
    with config.lock_fontes:
        for rec in config.receptores_ativos.values():
            rec.parar()

    if ndi_send:
        ndi.send_destroy(ndi_send)
    if ndi_send_v:
        ndi.send_destroy(ndi_send_v)
    if config.EXIBIR_JANELA_LOCAL:
        cv2.destroyAllWindows()
    ndi.destroy()
