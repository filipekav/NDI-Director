"""
web/routes.py — Rotas Flask do painel de controle NDI.

Define todos os endpoints REST e SSE:
  GET  /                          → painel HTML
  GET  /api/fontes                → lista de fontes e seus estados
  GET  /toggle/<nome>             → ativa/desativa um feed
  GET  /api/highlight/<nome>      → alterna modo destaque
  GET  /api/posicao/<nome>/<pos>  → define posição no mosaico (0-3)
  POST /api/definir_apelido/<nome>→ salva o apelido (GC) de uma fonte
  GET  /api/definir_fundo/<cor>   → altera a cor de fundo do mosaico
  GET  /api/eventos               → stream SSE de atualizações
"""
import queue
import logging

import cv2
import numpy as np
from flask import jsonify, request, Response, render_template

import config
import sse_manager
from ndi_receiver import ReceptorNDI
from web import app


# ---------------------------------------------------------------------------
# Painel principal
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    return render_template('painel.html')


# ---------------------------------------------------------------------------
# API de estado
# ---------------------------------------------------------------------------

@app.route('/api/fontes')
def api_fontes():
    with config.lock_fontes:
        dados = []
        for n in config.fontes_na_rede:
            ativo   = (n in config.receptores_ativos)
            posicao = config.ordem_receptores.index(n) if (ativo and n in config.ordem_receptores) else -1
            apelido = config.apelidos_fontes.get(n, "")
            erro    = config.receptores_ativos[n].erro if ativo else False
            dados.append({
                "nome":      n,
                "ativo":     ativo,
                "highlight": (n == config.fonte_highlight),
                "solo":      (n == config.fonte_solo),
                "posicao":   posicao,
                "apelido":   apelido,
                "erro":      erro,
            })
        return jsonify(dados)


# ---------------------------------------------------------------------------
# Controle de feeds
# ---------------------------------------------------------------------------

@app.route('/toggle/<path:nome>')
def toggle_source(nome):
    with config.lock_fontes:
        if nome in config.receptores_ativos:
            config.receptores_ativos[nome].parar()
            del config.receptores_ativos[nome]

            for i in range(4):
                if config.ordem_receptores[i] == nome:
                    config.ordem_receptores[i] = None
                    break

            if config.fonte_highlight == nome:
                config.fonte_highlight = None
            if config.fonte_solo == nome:
                config.fonte_solo = None
            print(f"[-] Desconectado: {nome}")
        else:
            if len(config.receptores_ativos) >= 4:
                print(f"[!] Limite de 4 feeds atingido. Não foi possível conectar: {nome}")
                return jsonify({"status": "limit_reached", "message": "Limite máximo de 4 feeds ativos atingido."}), 400

            config.receptores_ativos[nome] = ReceptorNDI(nome)
            for i in range(4):
                if config.ordem_receptores[i] is None:
                    config.ordem_receptores[i] = nome
                    break
            print(f"[+] Conectando: {nome}")

    sse_manager.notificar_clientes()
    return jsonify({"status": "ok"})


@app.route('/api/highlight/<path:nome>')
def toggle_highlight(nome):
    with config.lock_fontes:
        if nome not in config.receptores_ativos:
            return jsonify({"status": "error", "message": "A fonte precisa estar ativa para entrar em Highlight."}), 400

        if config.fonte_highlight == nome:
            config.fonte_highlight = None
            print(f"[*] Highlight desativado para: {nome}")
        else:
            config.fonte_highlight = nome
            print(f"[*] Highlight ativado para: {nome}")

    sse_manager.notificar_clientes()
    return jsonify({"status": "ok"})


@app.route('/api/solo/<path:nome>')
def toggle_solo(nome):
    with config.lock_fontes:
        if nome not in config.receptores_ativos:
            return jsonify({"status": "error", "message": "A fonte precisa estar ativa para entrar em Solo."}), 400

        if config.fonte_solo == nome:
            config.fonte_solo = None
            print(f"[*] Solo desativado para: {nome}")
        else:
            config.fonte_solo = nome
            config.fonte_highlight = None  # Solo cancela highlight
            print(f"[*] Solo ativado para: {nome}")

    sse_manager.notificar_clientes()
    return jsonify({"status": "ok"})


@app.route('/api/posicao/<path:nome>/<int:nova_pos>')
def definir_posicao_source(nome, nova_pos):
    with config.lock_fontes:
        if nome not in config.receptores_ativos:
            return jsonify({"status": "error", "message": "Fonte não está ativa."}), 400
        if nova_pos < 0 or nova_pos > 3:
            return jsonify({"status": "error", "message": "Posição inválida (0–3)."}), 400

        idx_atual = next((i for i in range(4) if config.ordem_receptores[i] == nome), -1)

        if idx_atual == nova_pos:
            return jsonify({"status": "ok"})

        if idx_atual != -1:
            config.ordem_receptores[idx_atual], config.ordem_receptores[nova_pos] = \
                config.ordem_receptores[nova_pos], config.ordem_receptores[idx_atual]
            print(f"[#] Troca de posição: {nome} (de {idx_atual} para {nova_pos})")
        else:
            config.ordem_receptores[nova_pos] = nome

    sse_manager.notificar_clientes()
    return jsonify({"status": "ok"})


@app.route('/api/definir_apelido/<path:nome>', methods=['POST'])
def definir_apelido(nome):
    dados   = request.get_json() or {}
    apelido = dados.get('apelido', '').strip()
    with config.lock_fontes:
        config.apelidos_fontes[nome] = apelido
        print(f"[*] Apelido definido para {nome}: '{apelido}'")
    sse_manager.notificar_clientes()
    return jsonify({"status": "ok"})


@app.route('/api/preview/<path:nome>')
def preview_frame(nome):
    """Retorna um JPEG thumbnail do frame atual do receptor NDI informado."""
    with config.lock_fontes:
        rec = config.receptores_ativos.get(nome)
        if rec is None or rec.frame_atual is None:
            return '', 204   # sem conteudo ainda
        frame = rec.frame_atual.copy()

    # Converte BGRA -> BGR e redimensiona para thumbnail 240x135
    bgr   = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    thumb = cv2.resize(bgr, (240, 135), interpolation=cv2.INTER_LINEAR)
    ok, buf = cv2.imencode('.jpg', thumb, [cv2.IMWRITE_JPEG_QUALITY, 80])
    if not ok:
        return '', 204
    return Response(buf.tobytes(), mimetype='image/jpeg')


@app.route('/api/definir_fundo/<cor>')
def definir_fundo(cor):
    with config.lock_fontes:
        if cor in config.CORES_BACKGROUND:
            config.cor_fundo_atual = cor
            print(f"[*] Fundo solicitado: {cor}")
            sse_manager.notificar_clientes()
            return jsonify({"status": "ok"})
    return jsonify({"status": "error", "message": "Cor inválida."}), 400


# ---------------------------------------------------------------------------
# SSE — Server-Sent Events
# ---------------------------------------------------------------------------

@app.route('/api/eventos')
def sse_eventos():
    """Mantém conexão aberta e envia 'update' sempre que o estado muda."""
    def gerar():
        q = sse_manager.criar_fila_cliente()
        try:
            yield "data: update\n\n"   # evento inicial
            while True:
                try:
                    q.get(timeout=25)
                    yield "data: update\n\n"
                except queue.Empty:
                    yield ": heartbeat\n\n"   # mantém a conexão TCP viva
        finally:
            sse_manager.remover_fila_cliente(q)

    return Response(
        gerar(),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'},
    )


# ---------------------------------------------------------------------------
# Servidor
# ---------------------------------------------------------------------------

def iniciar_servidor_web() -> None:
    """Inicia o Flask em modo silencioso (sem logs do werkzeug)."""
    logging.getLogger('werkzeug').setLevel(logging.ERROR)
    app.run(host='0.0.0.0', port=8634, debug=False, use_reloader=False)
