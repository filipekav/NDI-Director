"""
web/__init__.py — Instância do Flask.

Importar `app` daqui garante que há apenas uma instância Flask em todo o projeto.
O template_folder aponta para web/templates/ onde fica o painel.html.
"""
from flask import Flask

app = Flask(__name__, template_folder="templates")
